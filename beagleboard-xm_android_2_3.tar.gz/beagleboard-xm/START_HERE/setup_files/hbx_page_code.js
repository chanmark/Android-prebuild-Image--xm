<!--WEBSIDESTORY CODE HBX2.0 (Universal)-->
<!--COPYRIGHT 1997-2005 WEBSIDESTORY,INC. ALL RIGHTS RESERVED. U.S.PATENT No. 6,393,479B1. MORE INFO:http://websidestory.com/privacy-->
var _hbEC=0,_hbE=new Array;function _hbEvent(a,b){b=_hbE[_hbEC++]=new Object();b._N=a;b._C=0;return b;}
var hbx=_hbEvent("pv");hbx.vpc="HBX0200u";hbx.gn="ehg-ti.hitbox.com";

//BEGIN EDITABLE SECTION
if (!tiPageName) {
	var tiPageName="PUT+PAGE+NAME+HERE";    //page name(s)
}
if (!tiContentGroup) {
	var tiContentGroup="CONTENT+CATEGORY";  //multi-level content category
}
if (!tiFunnel) {
	var tiFunnel="";  //default funnel analysis
}
if (!tiLinkTracking) {
	var tiLinkTracking="auto";  //default Link Tracking setting
}
if (!tiDownLoadFilter) {
	var tiDownLoadFilter="n";  //default Download Filter
}
//CONFIGURATION VARIABLES
hbx.acct=acctNo;//ACCOUNT NUMBER(S)
hbx.pn=tiPageName;//PAGE NAME(S)
hbx.mlc=tiContentGroup;//MULTI-LEVEL CONTENT CATEGORY
hbx.lt=tiLinkTracking;//LINK TRACKING
hbx.fnl=tiFunnel;//FUNNELS
hbx.dlf=tiDownLoadFilter;//DOWNLOAD FILTER
hbx.ctdef="full";//DEFAULT CONTENT CATEGORY
//OPTIONAL PAGE VARIABLES
//ACTION SETTINGS
hbx.fv="handleSubmit";//FORM VALIDATION MINIMUM ELEMENTS OR SUBMIT FUNCTION NAME
hbx.dft="n";//DOWNLOAD FILE NAMING
hbx.elf="n";//EXIT LINK FILTER
//SEGMENTS AND FUNNELS
hbx.seg="";//VISITOR SEGMENTATION

//CAMPAIGNS
hbx.cmp="";//CAMPAIGN ID
hbx.cmpn="";//CAMPAIGN ID IN QUERY
hbx.dcmp="";//DYNAMIC CAMPAIGN ID
hbx.dcmpn="";//DYNAMIC CAMPAIGN ID IN QUERY
hbx.dcmpe="";//DYNAMIC CAMPAIGN EXPIRATION
hbx.dcmpre="";//DYNAMIC CAMPAIGN RESPONSE EXPIRATION
hbx.hra="";//RESPONSE ATTRIBUTE
hbx.hqsr="HQS";//RESPONSE ATTRIBUTE IN REFERRAL QUERY
hbx.hqsp="HQS";//RESPONSE ATTRIBUTE IN QUERY
hbx.hlt="";//LEAD TRACKING
hbx.hla="";//LEAD ATTRIBUTE
hbx.gp="";//CAMPAIGN GOAL
hbx.gpn="";//CAMPAIGN GOAL IN QUERY
hbx.hcn="";//CONVERSION ATTRIBUTE
hbx.hcv="";//CONVERSION VALUE
hbx.cp="null";//LEGACY CAMPAIGN
hbx.cpd="";//CAMPAIGN DOMAIN

//CUSTOM VARIABLES
hbx.ci="";//CUSTOMER ID
hbx.hc1="";//CUSTOM 1
hbx.hc2="";//CUSTOM 2
hbx.hc3="";//CUSTOM 3
hbx.hc4="";//CUSTOM 4
hbx.hrf="";//CUSTOM REFERRER
hbx.pec="";//ERROR CODES

//INSERT CUSTOM EVENTS
//END EDITABLE SECTION
<!--END WEBSIDESTORY CODE-->
